// cdh_monolithic.c
// TAB C Example CDH Monolithic
//
// Written by Bradley Denby
// Other contributors: Alok Anand
//
// See the top-level LICENSE file for the license.

// Standard library headers
#include <stddef.h> // size_t
#include <stdint.h> // uint8_t, uint32_t
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>

// Board-specific header
#include <cdh.h>    // CDH header

// TAB header
#include <tab.h>    // TAB header


// Main
int main(void) {
  // MCU initialization
  
  //added HSE clock initialisation and disabling internal PLL clock
  init_clock();
  //init_clock_hse();
   
  init_led();  
  init_uart();
  
  while(1) {
    for(int i=0; i<1600000; i++) {
      __asm__("nop");
    }
    gpio_toggle(GPIOC, GPIO10);
    gpio_toggle(GPIOC, GPIO12);
  }
  
  // TAB initialization
  rx_cmd_buff_t rx_cmd_buff = {.size=CMD_MAX_LEN};
  clear_rx_cmd_buff(&rx_cmd_buff);
  tx_cmd_buff_t tx_cmd_buff = {.size=CMD_MAX_LEN};
  clear_tx_cmd_buff(&tx_cmd_buff);
  // TAB loop
  while(1) {
    rx_usart1(&rx_cmd_buff);           // Collect command bytes
    reply(&rx_cmd_buff, &tx_cmd_buff); // Command reply logic
    tx_usart1(&tx_cmd_buff);           // Send a response if any
  }
  // Should never reach this point
  return 0;
}
