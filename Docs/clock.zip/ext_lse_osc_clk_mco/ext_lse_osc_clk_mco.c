// blink.c
// Makes the CDH board LEDs blink
//
// Written by Bradley Denby
// Other contributors: None
//
// See the top-level LICENSE file for the license.

// libopencm3
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include </home/abstract/git-repos/pq-cdh-su22-master/software/ext_lse_osc_clk_mco/pq-cdh/support.h>
int main(void) {

  init_clock();


 /* 

  __STATIC_INLINE uint32_t LL_RCC_GetLPUARTClockSource	(	uint32_t 	LPUARTx )	
  Get LPUARTx clock source CCIPR LPUART1SEL LL_RCC_GetLPUARTClockSource.

  Parameters:

  LPUARTx	This parameter can be one of the following values:
    LL_RCC_LPUART1_CLKSOURCE

  Return values:
  Returned	value can be one of the following values:
    LL_RCC_LPUART1_CLKSOURCE_PCLK1
    LL_RCC_LPUART1_CLKSOURCE_SYSCLK
    LL_RCC_LPUART1_CLKSOURCE_HSI
    LL_RCC_LPUART1_CLKSOURCE_LSE




  __STATIC_INLINE void LL_RCC_SetLPUARTClockSource	(	uint32_t 	LPUARTxSource )	
  //Configure LPUART1x clock source CCIPR LPUART1SEL LL_RCC_SetLPUARTClockSource.

  Parameters:

  LPUARTxSource	This parameter can be one of the following values:
    LL_RCC_LPUART1_CLKSOURCE_PCLK1
    LL_RCC_LPUART1_CLKSOURCE_SYSCLK
    LL_RCC_LPUART1_CLKSOURCE_HSI
    LL_RCC_LPUART1_CLKSOURCE_LSE

  Return values:
    None	

*/

void LL_RCC_SetLPUARTClockSource	(	uint32_t 	LPUARTxSource )












  //GPIO_InitTypeDef GPIO_InitStructure;

  //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
  rcc_periph_clock_enable(RCC_GPIOA);

  /* Output clock on MCO pin ---------------------------------------------*/
  gpio_mode_setup(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO8);
  gpio_set_output_options(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO8);
  gpio_set(GPIOA, GPIO8);
 
  //RCC_MCOConfig(RCC_MCOSource_PLLCLK_Div2); // Put on MCO pin the: System clock selected
  //rcc_set_mco(RCC_CFGR_MCO_PLL); //for PLL clk test
  rcc_set_mco(RCC_CFGR_MCO_HSE);

  rcc_periph_clock_enable(RCC_GPIOC);
  gpio_mode_setup(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO10);
  gpio_mode_setup(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO12);
  gpio_set(GPIOC, GPIO10);
  gpio_clear(GPIOC, GPIO12);
  while(1) {
    for(int i=0; i<1600000; i++) {
      __asm__("nop");
    }
    gpio_toggle(GPIOC, GPIO10);
    gpio_toggle(GPIOC, GPIO12);
  }

}
