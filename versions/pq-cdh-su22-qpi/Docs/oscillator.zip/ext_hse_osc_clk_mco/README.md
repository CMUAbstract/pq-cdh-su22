# Command and Data Handling Board Blink Software

Command and data handling board blink software

```bash
cd ../../scripts/
source sourcefile.txt
cd ../software/blink/
make
st-flash write blink.bin 0x8000000
```

## License

Written by Bradley Denby  
Other contributors: None

See the top-level LICENSE file for the license.
